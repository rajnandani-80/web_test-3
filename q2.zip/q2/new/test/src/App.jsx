import React, { useState } from 'react';

const TodoApp = () => {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState('medium');
  const [editingId, setEditingId] = useState(null);
  const [editTitle, setEditTitle] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editPriority, setEditPriority] = useState('medium');

  const addTask = (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    
    const newTask = {
      id: Date.now(),
      title,
      description,
      priority,
      completed: false
    };
    
    setTasks([...tasks, newTask]);
    setTitle('');
    setDescription('');
    setPriority('medium');
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  const toggleComplete = (id) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const startEditing = (task) => {
    setEditingId(task.id);
    setEditTitle(task.title);
    setEditDescription(task.description);
    setEditPriority(task.priority);
  };

  const saveEdit = (e) => {
    e.preventDefault();
    setTasks(tasks.map(task => 
      task.id === editingId ? { 
        ...task, 
        title: editTitle, 
        description: editDescription, 
        priority: editPriority 
      } : task
    ));
    setEditingId(null);
  };

  const cancelEdit = () => {
    setEditingId(null);
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return '#ff6b6b';
      case 'medium': return '#ffd166';
      case 'low': return '#06d6a0';
      default: return '#06d6a0';
    }
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.header}>To-Do List</h1>
      
      <form onSubmit={addTask} style={styles.form}>
        <div style={styles.formGroup}>
          <label style={styles.label}>Title:</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            style={styles.input}
            required
          />
        </div>
        
        <div style={styles.formGroup}>
          <label style={styles.label}>Description:</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            style={{...styles.input, height: '60px'}}
          />
        </div>
        
        <div style={styles.formGroup}>
          <label style={styles.label}>Priority:</label>
          <select
            value={priority}
            onChange={(e) => setPriority(e.target.value)}
            style={styles.select}
          >
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>
        
        <button type="submit" style={styles.addButton}>Add Task</button>
      </form>
      
      <div style={styles.taskList}>
        {tasks.length === 0 ? (
          <p style={styles.emptyMessage}>No tasks yet. Add one above!</p>
        ) : (
          tasks.map(task => (
            <div 
              key={task.id} 
              style={{
                ...styles.task,
                borderLeft: `4px solid ${getPriorityColor(task.priority)}`,
                textDecoration: task.completed ? 'line-through' : 'none',
                opacity: task.completed ? 0.7 : 1
              }}
            >
              {editingId === task.id ? (
                <form onSubmit={saveEdit} style={styles.editForm}>
                  <input
                    type="text"
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    style={styles.input}
                    required
                  />
                  <textarea
                    value={editDescription}
                    onChange={(e) => setEditDescription(e.target.value)}
                    style={{...styles.input, height: '50px'}}
                  />
                  <select
                    value={editPriority}
                    onChange={(e) => setEditPriority(e.target.value)}
                    style={styles.select}
                  >
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                  <div style={styles.editButtons}>
                    <button type="submit" style={styles.saveButton}>Save</button>
                    <button 
                      type="button" 
                      onClick={cancelEdit}
                      style={styles.cancelButton}
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              ) : (
                <>
                  <div style={styles.taskContent}>
                    <h3 style={styles.taskTitle}>{task.title}</h3>
                    <p style={styles.taskDescription}>{task.description}</p>
                    <span style={{
                      ...styles.priorityBadge,
                      backgroundColor: getPriorityColor(task.priority)
                    }}>
                      {task.priority}
                    </span>
                  </div>
                  <div style={styles.taskActions}>
                    <button 
                      onClick={() => toggleComplete(task.id)}
                      style={styles.completeButton}
                    >
                      {task.completed ? 'Undo' : 'Complete'}
                    </button>
                    <button 
                      onClick={() => startEditing(task)}
                      style={styles.editButton}
                    >
                      Edit
                    </button>
                    <button 
                      onClick={() => deleteTask(task.id)}
                      style={styles.deleteButton}
                    >
                      Delete
                    </button>
                  </div>
                </>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

const styles = {
  container: {
    maxWidth: '800px',
    margin: '0 auto',
    padding: '20px',
    fontFamily: 'Arial, sans-serif',
    Color: '#1477daff',
  },
  header: {
    textAlign: 'center',
    color: '#333',
    marginBottom: '30px'
  },
  form: {
    backgroundColor: '#eceef0ff',
    padding: '20px',
    borderRadius: '8px',
    marginBottom: '30px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
  },
  formGroup: {
    marginBottom: '15px'
  },
  label: {
    display: 'block',
    marginBottom: '5px',
    fontWeight: 'bold',
    color: '#333'
  },
  input: {
    width: '100%',
    padding: '8px',
    borderRadius: '4px',
    border: '1px solid #ddd',
    fontSize: '16px',
    boxSizing: 'border-box'
  },
  select: {
    width: '100%',
    padding: '8px',
    borderRadius: '4px',
    border: '1px solid #ddd',
    fontSize: '16px',
    backgroundColor: 'white'
  },
  addButton: {
    backgroundColor: '#4CAF50',
    color: 'white',
    border: 'none',
    padding: '10px 15px',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '16px',
    width: '100%',
    marginTop: '10px'
  },
  taskList: {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px'
  },
  task: {
    backgroundColor: 'white',
    padding: '15px',
    borderRadius: '8px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  taskContent: {
    flex: 1
  },
  taskTitle: {
    margin: '0 0 5px 0',
    color: '#333'
  },
  taskDescription: {
    margin: '0 0 10px 0',
    color: '#666'
  },
  priorityBadge: {
    display: 'inline-block',
    padding: '3px 8px',
    borderRadius: '12px',
    fontSize: '12px',
    color: 'white',
    fontWeight: 'bold'
  },
  taskActions: {
    display: 'flex',
    gap: '8px',
    marginLeft: '15px'
  },
  completeButton: {
    backgroundColor: '#2196F3',
    color: 'white',
    border: 'none',
    padding: '5px 10px',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px'
  },
  editButton: {
    backgroundColor: '#FFC107',
    color: 'black',
    border: 'none',
    padding: '5px 10px',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px'
  },
  deleteButton: {
    backgroundColor: '#f44336',
    color: 'white',
    border: 'none',
    padding: '5px 10px',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '14px'
  },
  emptyMessage: {
    textAlign: 'center',
    color: '#666',
    fontStyle: 'italic'
  },
  editForm: {
    width: '100%',
    display: 'flex',
    flexDirection: 'column',
    gap: '10px'
  },
  editButtons: {
    display: 'flex',
    gap: '10px',
    marginTop: '10px'
  },
  saveButton: {
    backgroundColor: '#4CAF50',
    color: 'white',
    border: 'none',
    padding: '8px 12px',
    borderRadius: '4px',
    cursor: 'pointer',
    flex: 1
  },
  cancelButton: {
    backgroundColor: '#f44336',
    color: 'white',
    border: 'none',
    padding: '8px 12px',
    borderRadius: '4px',
    cursor: 'pointer',
    flex: 1
  }
};

export default TodoApp;