import React from 'react';
import useFetchUsers from '../hooks/useFetchUsers';
import './UserList.css';

const UserList = () => {
  const { data: users, loading, error } = useFetchUsers('https://jsonplaceholder.typicode.com/users');

  return (
    <div className="user-container">
      <h1>User Directory</h1>

      {loading && (
        <div className="loading">
          <div className="spinner"></div>
          <p>Loading users...</p>
        </div>
      )}

      {error && <div className="error">Error: {error}</div>}

      <div className="user-grid">
        {users.map(user => (
          <div key={user.id} className="user-card">
            <h2>{user.name}</h2>
            <p><strong>Username:</strong> {user.username}</p>
            <p><strong>Email:</strong> {user.email}</p>
            <p><strong>Phone:</strong> {user.phone}</p>
            <p><strong>Website:</strong> <a href={`http://${user.website}`} target="_blank" rel="noreferrer">{user.website}</a></p>
            <p><strong>Company:</strong> {user.company.name}</p>
            <p><strong>CatchPhrase:</strong> {user.company.catchPhrase}</p>
            <p><strong>Address:</strong> {user.address.street}, {user.address.suite}, {user.address.city}, {user.address.zipcode}</p>
            <p><strong>Geo:</strong> Lat: {user.address.geo.lat}, Lng: {user.address.geo.lng}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default UserList;
